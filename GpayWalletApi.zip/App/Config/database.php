<?php
    class DB{
        const username = 'root';
        const password = '';
        const database = 'gpay_wallet';
        const model_directory = 'App/Models';
    }