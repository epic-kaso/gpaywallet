
<div class="container">
    <div class="row">
        <div class="col-sm-10 col-sm-offset-1 login-box">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h4>Your Wallet Apps</h4>
                </div>
                <table class="table table-striped">
                    <thead>
                    <tr>
                        <td>S/N</td>
                        <td>ID</td>
                        <td>Name</td>
                        <td>Active</td>
                        <td>..</td>
                    </tr>
                    </thead>

                    <tbody>
                    <tr>
                        <td>1</td>
                        <td>1WEJK34ONU</td>
                        <td>SUPERGEEKS STORE</td>
                        <td><span class="label label-success">YES</span></td>
                        <td><button class="btn btn-xs btn-default">change</button></td>
                    </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>