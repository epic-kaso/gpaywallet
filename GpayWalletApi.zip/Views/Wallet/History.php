

<div class="container">
    <div class="row">
        <div class="col-sm-10 col-sm-offset-1 login-box">

            <div class="panel panel-default">
                <div class="panel-heading">
                    <h4>Transactions History.</h4>
                </div>
                <table class="table table-striped">
                    <thead>
                    <tr>
                        <td>S/N</td>
                        <td>Application</td>
                        <td>Transaction type</td>
                        <td>Amount (N)</td>
                    </tr>
                    </thead>

                    <tbody>
                    <tr>
                        <td>1</td>
                        <td>Supergeeks Nigeria</td>
                        <td><span class="label label-warning">DEBIT</span></td>
                        <td>100</td>
                    </tr>
                    <tr>
                        <td>1</td>
                        <td>Supergeeks Nigeria</td>
                        <td><span class="label label-warning">DEBIT</span></td>
                        <td>100</td>
                    </tr>
                    <tr>
                        <td>1</td>
                        <td>Supergeeks Nigeria</td>
                        <td><span class="label label-warning">DEBIT</span></td>
                        <td>100</td>
                    </tr>
                    <tr>
                        <td>1</td>
                        <td>Supergeeks Nigeria</td>
                        <td><span class="label label-warning">DEBIT</span></td>
                        <td>100</td>
                    </tr>
                    <tr>
                        <td>1</td>
                        <td>Supergeeks Nigeria</td>
                        <td><span class="label label-warning">DEBIT</span></td>
                        <td>100</td>
                    </tr>
                    </tbody>
                </table>
            </div>

            <div>
                <ul class="pagination">
                    <li><a href="#">< PREVIOUS</a></li>
                    <li><a href="#">NEXT ></a></li>
                </ul>
            </div>
        </div>
    </div>
</div>