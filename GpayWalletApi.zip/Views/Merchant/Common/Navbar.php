<div class="navbar navbar-gpay-merchant navbar-fixed-top">
    <div class="container">
        <div class="navbar-header">
            <img src="/Public/images/logo.png" class="navbar-brand" />
        </div>
        <ul class="nav navbar-nav">
            <li><a href="/api/v1/merchant/">DASHBOARD</a></li>
            <li><a href="/api/v1/merchant/apps">APPS</a></li>
            <li><a href="/api/v1/merchant/wallet/balance">WALLET</a></li>
            <li><a href="/api/v1/merchant/apps/generate-button">API</a></li>
        </ul>

        <ul class="nav navbar-nav pull-right">
            <li><a href="/api/v1/merchant/profile">PROFILE</a></li>
            <li><a href="/merchant/logout">LOGOUT</a></li>
        </ul>
    </div>
</div>