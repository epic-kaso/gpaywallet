<?php include_once './Views/Merchant/Common/Navbar.php'; ?>

<div class="container">
    <div class="row">
        <div class="col-sm-10 col-sm-offset-1 login-box">

            <div class="panel panel-default">
                <div class="panel-heading">
                    <span>Profile Edit.</span>
                    <a class="btn btn-default btn-xs pull-right" href="/api/v1/merchant/profile">View</a>
                </div>
                <div class="panel-body">
                <div class="form-group">
                    <label>Merchant ID: </label>
                    <span class="form-control-static"><?= $merchant->merchant_id ?></span>
                </div>

                <div class="form-group">
                    <label>Phone: </label>
                    <input class="form-control" placeholder="Phone Number" value="<?= $merchant->merchant_id ?>`" name="phone"/>
                </div>

                <div class="form-group">
                    <label>Password: </label>
                    <input class="form-control" placeholder="Password" name="password" type="password"/>
                </div>

                <div class="form-group">
                    <label>Confirm Password: </label>
                    <input class="form-control" placeholder="Confirm Password" name="confirm_password" type="password"/>
                </div>

                    <div class="form-group">
                        <label>Bank: </label>
                        <select class="form-control" name="bank_name">
                            <optgroup label="SELECT BANK">
                                <option>ACCESS BANK</option>
                                <option>KEYSTONE BANK</option>
                                <option>DIAMOND BANK</option>
                                <option>ENTERPRISE BANK</option>
                                <option>ECO BANK</option>
                                <option>FIDELITY BANK</option>
                                <option>FIRST BANK</option>
                                <option>FCMB BANK</option>
                                <option>GT BANK</option>
                                <option>SKYE BANK</option>
                                <option>UNION BANK</option>
                                <option>UBA BANK</option>
                                <option>ZENITH BANK</option>
                            </optgroup>
                        </select>
                    </div>

                    <div class="form-group">
                        <label>Bank Account Name: </label>
                        <input class="form-control" type="text" name="bank_account_name" placeholder="Bank Account Name"/>
                    </div>

                    <div class="form-group">
                        <label>Bank Account Number: </label>
                        <input class="form-control" type="number" min="0000000000" name="bank_account_number" placeholder="ACCOUNT NUMBER"/>
                    </div>

                <div class="form-group">
                    <input class="btn btn-primary" value="Save" type="submit" />
                </div>
                </div>
            </div>
        </div>
    </div>
</div>